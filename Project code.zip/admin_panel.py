from tkinter import *
from PIL import ImageTk,Image
# import pymysql
# from tkinter import messagebox
from View_books import *
from Add_book import *
from Delet_book import *


def admin_pnl():
    root = Tk()
    root.title("Admin Panel")
    root.minsize(width=400, height=400)
    root.geometry("800x600")

    Canvas1 = Canvas(root)
    Canvas1.config(bg="#66ff66")
    Canvas1.pack(expand=True,fill=BOTH)

    headingFrame1 = Frame(root,bg="#33cc33",bd=5)
    headingFrame1.place(relx=0.2,rely=0.1,relwidth=0.6,relheight=0.16)

    headingLabel = Label(headingFrame1, text="Welcome to \n DataFlair Library", bg='#ffff4d', fg='black', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)

    btn1 = Button(root,text="Add Book Details",bg='#0099ff', fg='black', font=('Courier',18), command=addBook)
    btn1.place(relx=0.28,rely=0.4, relwidth=0.45,relheight=0.1)
        
    btn2 = Button(root,text="Delete Book",bg='#0099ff', fg='black', font=('Courier',18),command=delete)
    btn2.place(relx=0.28,rely=0.5, relwidth=0.45,relheight=0.1)
        
    btn3 = Button(root,text="View Book List",bg='#0099ff', fg='black', font=('Courier',18), command=View)
    btn3.place(relx=0.28,rely=0.6, relwidth=0.45,relheight=0.1)

    root.mainloop()


if __name__=="__main__":
    admin_pnl()