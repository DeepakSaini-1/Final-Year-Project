from datetime import date
import pymysql
from tkinter import messagebox
from Connect_DB import *
import cv2
import numpy as np
from pyzbar.pyzbar import decode
import threading
import winsound

def play_beep():
    winsound.Beep(1000, 300)  
    check=0

def check_StudentID(StudentID):
    tem = mysqlconnect()
    cur = tem.cursor()
    check_stu_ID=f"select * from students where ID='{StudentID}';"
    try:
        cur.execute(check_stu_ID)
        check=cur.fetchall()
        tem.commit()
        if check==():
            return False
        else:
            return True
    except:
        messagebox.showinfo('Error',"Not check student record")


def is_Available(BookID):
    check=[[0]]

    tem = mysqlconnect()
    cur = tem.cursor()

    deleteSql = f"select Availability from books where id='{BookID}'"
    try:
        cur.execute(deleteSql)
        # check=cur.execute(deleteSql)
        check=cur.fetchall()
        tem.commit()
    except:
        messagebox.showinfo('Error',"Book availability not checked")

    
    if check==():
        return False
    
    if check[0][0]:
        return True
    else:
        return False


def save_data(BookID,StudentID):
    tem = mysqlconnect()
    cur = tem.cursor()

    
    if is_Available(BookID) and check_StudentID(StudentID):
        deleteSql = f"INSERT INTO Transactions (BookID, StudentID, IssueDate, ReturnDate) VALUES  ('{BookID}','{StudentID}','{date.today()}',NULL)"
        updatesql=f"update books set Availability=false where id='{BookID}'"
        try:
            cur.execute(deleteSql)
            cur.execute(updatesql)
            tem.commit()
            messagebox.showinfo('Success',"Book issue Successfully\nThanks")
        except:
            messagebox.showinfo('Error',"Book not issue\nTry again")
    else:
        messagebox.showinfo('Availability',"Book is not Availability")

def issue_book():
    BookID=None
    StudentID=None

    # Initialize the webcam (0 is default camera)
    cap = cv2.VideoCapture(0)

    # Variable to store scanned data (to avoid repeated beeps)
    scanned_data = set()

    print("📷 Starting camera... Show a QR Code to scan.")

    while True:

        success, frame = cap.read()  # Read frame from camera
        if not success:
            print("❌ Failed to read from camera.")
            break

        # Decode any QR codes in the frame
        qr_codes = decode(frame)
        for qr in qr_codes:
            data = qr.data.decode('utf-8')  # Convert byte data to string
            if data not in scanned_data:
                data2=data.split(",")

                print(f"✅ QR Code Detected: {data}")
                if data2[0]=="Student":
                    StudentID=data2[1]
                elif data2[0]=="Book":
                    BookID=data2[1]
                    scanned_data.add(data)

                scanned_data.add(data)

                # Draw rectangle around QR code
                pts = qr.polygon
                pts = [(pt.x, pt.y) for pt in pts]
                pts_array = np.array([pts], dtype=np.int32)
                
                # cv2.polylines(frame, [np.array(pts)], isClosed=True, color=(0, 255, 0), thickness=2)
                cv2.polylines(frame, pts_array, isClosed=True, color=(0, 255, 0), thickness=2)

                # Play beep sound in a separate thread
                threading.Thread(target=play_beep).start()

                if BookID!=None and StudentID!=None:
                    save_data(BookID,StudentID)
                    BookID=None
                    StudentID=None
                    scanned_data = set()

        # Show the live camera feed
        cv2.imshow("QR Code Scanner", frame)

        # Press 'q' to quit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close all windows
    cap.release()
    cv2.destroyAllWindows()
  


if __name__=="__main__":
    # save_data(BookID=3,StudentID=7)
    issue_book()