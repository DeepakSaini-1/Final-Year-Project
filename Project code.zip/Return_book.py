from datetime import date
import pymysql
from tkinter import messagebox
from Connect_DB import *
import cv2
import numpy as np
from pyzbar.pyzbar import decode
import threading
import winsound

def play_beep():
    winsound.Beep(1000, 300)  


def is_Available(BookID):
    tem = mysqlconnect()
    cur = tem.cursor()

    deleteSql = f"select Availability from books where id='{BookID}'"
    try:
        check=cur.execute(deleteSql)
        check=cur.fetchall()
        tem.commit()
    except:
        messagebox.showinfo('Error',"Book availability not checked")

    if check[0][0]:
        return True
    else:
        return False
    

def update(BookID):
    tem = mysqlconnect()
    cur = tem.cursor()

    find_TransactionID=f"select TransactionID from Transactions where bookid='{BookID}' && ReturnDate is null"
    cur.execute(find_TransactionID) # find transaction id for update return date
    data = cur.fetchall()
    
    if data!=():
        return_date = f"update Transactions set ReturnDate='{date.today()}' where TransactionID={data[0][0]}"
        updatesql=f"update books set Availability=true where id='{BookID}'"
        try:
            cur.execute(return_date)
            cur.execute(updatesql)
            tem.commit()
            messagebox.showinfo('Success',"Book return Successfully\nThanks")
        except:
            messagebox.showinfo('Error',"Book not return\nTry again")
    else:
        messagebox.showinfo('Error',"Book not found\nTry again")



def return_book():
    BookID=None

    # Initialize the webcam (0 is default camera)
    cap = cv2.VideoCapture(0)

    # Variable to store scanned data (to avoid repeated beeps)
    scanned_data = set()

    print("📷 Starting camera... Show a QR Code to scan.")

    while True:

        success, frame = cap.read()  # Read frame from camera
        if not success:
            print("❌ Failed to read from camera.")
            break

        # Decode any QR codes in the frame
        qr_codes = decode(frame)
        for qr in qr_codes:
            data = qr.data.decode('utf-8')  # Convert byte data to string
            if data not in scanned_data:
                data2=data.split(",")

                print(f"✅ QR Code Detected: {data}")
                if data2[0]=="Book":
                    BookID=data2[1]

                scanned_data.add(data)

                # Draw rectangle around QR code
                pts = qr.polygon
                pts = [(pt.x, pt.y) for pt in pts]
                pts_array = np.array([pts], dtype=np.int32)
                
                # cv2.polylines(frame, [np.array(pts)], isClosed=True, color=(0, 255, 0), thickness=2)
                cv2.polylines(frame, pts_array, isClosed=True, color=(0, 255, 0), thickness=2)

                # Play beep sound in a separate thread
                threading.Thread(target=play_beep).start()

                if BookID!=None:
                    update(BookID)
                    BookID=None

        # Show the live camera feed
        cv2.imshow("QR Code Scanner", frame)

        # Press 'q' to quit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close all windows
    cap.release()
    cv2.destroyAllWindows()
  


if __name__=="__main__":
    # save_data(BookID=3,StudentID=7)
    # return_book()
    update('B010')

