from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql
from Connect_DB import *
import qrcode

def generate_QR(bid,title,author):
    # Step 1: Data to be stored in QR Code
    data=f"Book,{bid},{title},{author}"
    
    # Step 2: Create QR Code object
    qr = qrcode.QRCode(
    version=1,  # controls the size of the QR Code (1 to 40)
    error_correction=qrcode.constants.ERROR_CORRECT_L,  # error correction level
    box_size=10,  # size of each box in pixels
    border=2,  # thickness of the border
    )

    # Step 3: Add data to the QR code
    qr.add_data(data)
    qr.make(fit=True)

    # Step 4: Create an image from the QR Code
    img = qr.make_image(fill_color="black", back_color="white")

    # Step 5: Save the image
    img.save(f"QR Code\Book\{bid}.png")

    print(f"QR Code generated and saved as {bid}.png")
    # print(data)
    

def bookRegister():
    global bid,title,author

    tem = mysqlconnect()
    cur = tem.cursor()
    
    bid = bookInfo1.get()
    title = bookInfo2.get()
    author = bookInfo3.get()

    try:
        insertBooks=f"insert into books values ('{bid}','{title}','{author}',True)"
        cur.execute(insertBooks)
        tem.commit()
        generate_QR(bid,title,author)
        messagebox.showinfo('Success',"Book added successfully")
    except:
        messagebox.showinfo("Error","Can't add data into Database")

    bookInfo1.delete(0, END)
    bookInfo2.delete(0, END)
    bookInfo3.delete(0, END)

    
def addBook(): 
    
    global bookInfo1,bookInfo2,bookInfo3,Canvas1,root,var
    
    root = Tk()
    root.title("Library")
    root.minsize(width=400,height=400)
    root.geometry("600x500")
    Canvas1 = Canvas(root)
    
    Canvas1.config(bg="#ff6e40")
    Canvas1.pack(expand=True,fill=BOTH)
        
    headingFrame1 = Frame(root,bg="#FFBB00",bd=5)
    headingFrame1.place(relx=0.25,rely=0.1,relwidth=0.5,relheight=0.13)

    headingLabel = Label(headingFrame1, text="Add Books", bg='black', fg='white', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)


    labelFrame = Frame(root,bg='black')
    labelFrame.place(relx=0.1,rely=0.4,relwidth=0.8,relheight=0.4)
        
    # Book ID
    lb1 = Label(labelFrame,text="Book ID : ", bg='black', fg='white')
    lb1.place(relx=0.05,rely=0.2, relheight=0.08)
        
    bookInfo1 = Entry(labelFrame)
    bookInfo1.place(relx=0.3,rely=0.2, relwidth=0.62, relheight=0.08)
        
    # Title
    lb2 = Label(labelFrame,text="Title : ", bg='black', fg='white')
    lb2.place(relx=0.05,rely=0.35, relheight=0.08)
        
    bookInfo2 = Entry(labelFrame)
    bookInfo2.place(relx=0.3,rely=0.35, relwidth=0.62, relheight=0.08)
        
    # Book Author
    lb3 = Label(labelFrame,text="Author : ", bg='black', fg='white')
    lb3.place(relx=0.05,rely=0.50, relheight=0.08)
        
    bookInfo3 = Entry(labelFrame)
    bookInfo3.place(relx=0.3,rely=0.50, relwidth=0.62, relheight=0.08)
        
    # Book Status
    # lb4 = Label(labelFrame,text="Status : ", bg='black', fg='white')
    # lb4.place(relx=0.05,rely=0.65, relheight=0.08)

    # # Variable to store the checkbox state (0 = False, 1 = True)
    # var = IntVar()
    # checkbox = Checkbutton(root, text="Available", variable=var, onvalue=1, offvalue=0)
    # checkbox.place(relx=0.34,rely=0.65)
        
    #Submit Button
    SubmitBtn = Button(root,text="SUBMIT",bg='#d1ccc0', fg='black',command=bookRegister)
    SubmitBtn.place(relx=0.28,rely=0.9, relwidth=0.18,relheight=0.08)
    
    quitBtn = Button(root,text="Quit",bg='#f7f1e3', fg='black', command=root.destroy)
    quitBtn.place(relx=0.53,rely=0.9, relwidth=0.18,relheight=0.08)
    
    root.mainloop()

if __name__=="__main__":
    addBook()
    # def generate_QR()