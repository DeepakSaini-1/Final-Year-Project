import pymysql
 

def mysqlconnect(): 
	# To connect MySQL database 
	conn = pymysql.connect( 
		host='localhost', 
		user='root', 
		password = "ASDF@12318", 
		db='SLMS_Project', 
		)
	
	return conn

# Driver Code 
if __name__ == "__main__" : 
	mysqlconnect()
