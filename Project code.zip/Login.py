from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql
from Connect_DB import *
from admin_panel import *
from Student_panel import *

stu_login=True
admin='admin@123'

def login():
    global username_ID

    username_ID=username_entry.get()
    passwd=password_entry.get()

    if stu_login:
        tem = mysqlconnect()
        cur = tem.cursor()


        query=f'select * from Students where id="{username_ID}" && passwd="{passwd}"'
        cur.execute(query)
        data = cur.fetchall()

        if data==():
            messagebox.showinfo("Error","Student not found!\ncheck you ID and password")
        else:
            Student_pnl(username_ID, passwd)

        tem.close()

    else:
        if username_ID=="admin" and passwd=="admin@123":
            admin_pnl()
            
        else:
            messagebox.showinfo("Error","wrong admin password!\ncheck password")

    root.destroy() #now
        



def to_admin():
    global stu_login #now
    stu_login=False

def to_stu():
    global stu_login #now
    stu_login=True

def log():

    global username_entry,password_entry,root

    # Create main window
    root = Tk()
    root.title("Login")
    root.geometry("400x300")
    root.configure(bg='white')


    # admin Login button
    admin_login_button = Button(root, text="Admin Login", bg="dodgerblue", fg="white", width=10, command=to_admin)
    admin_login_button.place(relx=0.20,rely=0.15, relwidth=0.20,relheight=0.1)

    # student Login button
    stu_login_button = Button(root, text="Student Login", bg="dodgerblue", fg="white", width=10, command=to_stu)
    stu_login_button.place(relx=0.55,rely=0.15, relwidth=0.20,relheight=0.1)

    # Username label and entry
    username_label = Label(root, text="Username :", bg="white", anchor='w')
    username_label.place(relx=0.20,rely=0.27, relwidth=0.50,relheight=0.1)
    username_entry = Entry(root, width=30, bd=2, relief=SUNKEN)
    username_entry.place(relx=0.20,rely=0.35, relwidth=0.55,relheight=0.1)

    # Password label and entry
    password_label = Label(root, text="Password:", bg="white", anchor='w')
    password_label.place(relx=0.20,rely=0.45, relwidth=0.50,relheight=0.1)
    password_entry = Entry(root, show="*", width=30, bd=2, relief=SUNKEN)
    password_entry.place(relx=0.20,rely=0.53, relwidth=0.55,relheight=0.1)
        
    # Login button
    login_button = Button(root, text="Login", bg="dodgerblue", fg="white", width=10, command=login)
    login_button.place(relx=0.35,rely=0.65, relwidth=0.30,relheight=0.1)
    root.mainloop()



if __name__=="__main__":
    log()
    # stu_iss_book()

