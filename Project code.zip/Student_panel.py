from tkinter import *
from PIL import ImageTk,Image
import pymysql
from tkinter import messagebox
from View_books import *
from Issue_book import *
from Return_book import * 
from Connect_DB import *



def update_password():
    current = current_pass.get()
    new = new_pass.get()
    confirm = confirm_pass.get()
    
    tem = mysqlconnect()
    cur = tem.cursor()

    if not current or not new or not confirm:
        messagebox.showwarning("Input Error", "All fields are required")
    elif new != confirm:
        messagebox.showerror("Mismatch", "New passwords do not match")
    else:
        # Here you would normally validate current password and update it in DB
        if current==passwd:
            updatesql=f'update Students set passwd="{new}"  where id="{username_ID}"'
            try:
                cur.execute(updatesql)
                tem.commit()
                messagebox.showinfo("Success", "Password updated successfully!")
                tem.close()
            except:
                messagebox.showwarning("Input Error", "Password not update\nTry again")
        else:
            messagebox.showerror("Mismatch", "current passwords do not match")


def change_passwd():
    global current_pass,new_pass,confirm_pass
    # Main window
    root = Tk()
    root.title("Change Password")
    root.geometry("400x300")
    root.configure(bg="white")

    # Heading
    heading = Label(root, text="Change password", font=("Helvetica", 16, "bold"), bg="white")
    heading.pack(pady=10)

    # Current password
    Label(root, text="Current password", bg="white").pack(pady=(10, 0))
    current_pass = Entry(root, show="*", width=30, bd=2, relief=GROOVE)
    current_pass.pack()

    # New password
    Label(root, text="New password", bg="white").pack(pady=(10, 0))
    new_pass = Entry(root, show="*", width=30, bd=2, relief=GROOVE)
    new_pass.pack()

    # Confirm new password
    Label(root, text="Confirm new password", bg="white").pack(pady=(10, 0))
    confirm_pass = Entry(root, show="*", width=30, bd=2, relief=GROOVE)
    confirm_pass.pack()

    # Update button
    update_btn = Button(root, text="Update password", bg="#008CFF", fg="white",command=update_password)
    update_btn.pack(pady=20)

    root.mainloop()

def stu_iss_book():
    # global username_ID
    tem = mysqlconnect()
    cur = tem.cursor()
    print(username_ID)

    root = Tk()
    root.title("Library")
    root.geometry("850x500")

    # === Main frame with canvas and scrollbar ===
    main_frame = Frame(root)
    main_frame.pack(fill=BOTH, expand=1)

    canvas = Canvas(main_frame, bg="#12a4d9")
    canvas.pack(side=LEFT, fill=BOTH, expand=1)

    scrollbar = Scrollbar(main_frame, orient=VERTICAL, command=canvas.yview)
    scrollbar.pack(side=RIGHT, fill=Y)

    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # === Frame inside the canvas ===
    second_frame = Frame(canvas, bg="#12a4d9")
    canvas.create_window((0, 0), window=second_frame, anchor="nw")

    # === Heading ===
    headingFrame1 = Frame(second_frame, bg="#FFBB00", bd=5)
    headingFrame1.pack(pady=20)

    headingLabel = Label(headingFrame1, text="View Issue Books", bg='black', fg='white', font=('Courier', 15))
    headingLabel.pack(fill=BOTH)

    # === Book list heading ===
    labelFrame = Frame(second_frame, bg='black')
    labelFrame.pack(pady=10, padx=10, fill=X)

    Label(labelFrame, text="%-20s%-20s%-30s%-30s" % ('TransactionID', 'BookID', 'StudentID', 'IssueDate'),
          bg='black', fg='white', anchor='w', font=("Courier", 10)).pack(fill=X)
    Label(labelFrame, text="-" * 150, bg='black', fg='white').pack(fill=X)

    # === Fetch & Display books ===
    getBooks = f"select * from transactions where studentid='{username_ID}' && returndate is null"
    # getBooks = "SELECT * FROM books"
    cur.execute(getBooks)
    data = cur.fetchall()

    for i in data:
        text = "%-20s%-20s%-30s%-30s" % (i[0], i[1], i[2], i[3])
        Label(labelFrame, text=text, bg='black', fg='white', anchor='w', font=("Courier", 10)).pack(fill=X)

    # === Quit button ===
    quitBtn = Button(second_frame, text="Quit", bg='#f7f1e3', fg='black', command=root.destroy)
    quitBtn.pack(pady=20)

    tem.close()
    root.mainloop()


def Student_pnl(ID,stu_passwd):
    global username_ID, passwd
    username_ID=ID
    # username_ID='S010'
    passwd=stu_passwd
    print(username_ID)
    print(ID)
    print(passwd)
    print(stu_passwd)

    root = Tk()
    root.title("Student Panel")
    root.minsize(width=400, height=400)
    root.geometry("800x600")

    Canvas1 = Canvas(root)
    Canvas1.config(bg="#66ff66")
    Canvas1.pack(expand=True,fill=BOTH)

    headingFrame1 = Frame(root,bg="#33cc33",bd=5)
    headingFrame1.place(relx=0.2,rely=0.1,relwidth=0.6,relheight=0.16)

    headingLabel = Label(headingFrame1, text="Welcome to \n DataFlair Library", bg='#ffff4d', fg='black', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)

    cng_passwd = Button(root,text="Change password",bg='black', fg='white', command=change_passwd)
    cng_passwd .place(relx=0.85,rely=0.01, relwidth=0.14,relheight=0.06)

    btn1 = Button(root,text="View Books ",bg='#0099ff', fg='black',font=('Courier',18), command=View)
    btn1.place(relx=0.28,rely=0.4, relwidth=0.45,relheight=0.1)
        
    btn2 = Button(root,text="Issue Book List",bg='#0099ff', fg='black',font=('Courier',18),command=stu_iss_book)
    btn2.place(relx=0.28,rely=0.5, relwidth=0.45,relheight=0.1)
        
    btn3 = Button(root,text="New Book Issue",bg='#0099ff', fg='black',font=('Courier',18),command=issue_book)
    btn3.place(relx=0.28,rely=0.6, relwidth=0.45,relheight=0.1)

    btn4 = Button(root,text="Return Book",bg='#0099ff', fg='black',font=('Courier',18), command=return_book)
    btn4.place(relx=0.28,rely=0.7, relwidth=0.45,relheight=0.1)

    root.mainloop()


if __name__=="__main__":
    # Student_pnl()
    # change_passwd()
    Student_pnl()
    stu_iss_book()