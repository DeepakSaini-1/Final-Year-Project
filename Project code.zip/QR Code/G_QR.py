import qrcode

# Create Student QR codes, formate : Student, student-ID, Student-name, student-rool-no., contact-no.
data =[
    "Student,S001,Aarav Sharma,R101,9876543210",
"Student,S002,Isha Verma,R102,9823456789",
"Student,S003,Kabir Mehta,R103,912345678",
"Student,S004,Ananya Singh,R104,9801122334",
"Student,S005,Vivaan Kapoor,R105,9898989898",
"Student,S006,Diya Patel,R106,9753124680",
"Student,S007,Aryan Joshi,R107,994612378",
"Student,S008,Tara Nair,R108,9638527410",
"Student,S009,Krish Rao,R109,9977554433",
"Student,S010,Meera Das,R110,9900112233"
]

# Create Book QR codes, formate : Book, book-id, book-titel, book-author.
# data = [
# "Book,B012,The Alchemist,Paulo Coelho",
# "Book,B001,The Alchemist,Paulo Coelho",
# "Book,B002,To Kill a Mockingbird,Harper Lee",
# "Book,B003,1984,George Orwell",
# "Book,B004,The Great Gatsby,F. Scott Fitzgerald",
# "Book,B005,Pride and Prejudice,Jane Austen",
# "Book,B006,The Hobbit,J.R.R. Tolkien",
# "Book,B007,The Catcher in the Rye,J.D. Salinger",
# "Book,B008,The Lord of the Rings,J.R.R. Tolkien",
# "Book,B009,The Diary of a Young Girl,Anne Frank",
# "Book,B010,Brave New World,Aldous Huxley"
# ]


# Step 1: Data to be stored in QR Code
for i in data:

    # Step 2: Create QR Code object
    qr = qrcode.QRCode(
    version=1,  # controls the size of the QR Code (1 to 40)
    error_correction=qrcode.constants.ERROR_CORRECT_L,  # error correction level
    box_size=10,  # size of each box in pixels
    border=2,  # thickness of the border
    )

    # Step 3: Add data to the QR code
    qr.add_data(i)
    qr.make(fit=True)

    # Step 4: Create an image from the QR Code
    img = qr.make_image(fill_color="black", back_color="white")

    # Step 5: Save the image
    img.save(f"{i[5:9]}.png")

    print(f"QR Code generated and saved as {i[5:9]}.png")
