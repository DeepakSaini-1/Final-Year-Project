from tkinter import *
import pymysql
from Connect_DB import *

def View():
    tem = mysqlconnect()
    cur = tem.cursor()

    root = Tk()
    root.title("Library")
    root.geometry("850x500")

    # === Main frame with canvas and scrollbar ===
    main_frame = Frame(root)
    main_frame.pack(fill=BOTH, expand=1)

    canvas = Canvas(main_frame, bg="#12a4d9")
    canvas.pack(side=LEFT, fill=BOTH, expand=1)

    scrollbar = Scrollbar(main_frame, orient=VERTICAL, command=canvas.yview)
    scrollbar.pack(side=RIGHT, fill=Y)

    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # === Frame inside the canvas ===
    second_frame = Frame(canvas, bg="#12a4d9")
    canvas.create_window((0, 0), window=second_frame, anchor="nw")

    # === Heading ===
    headingFrame1 = Frame(second_frame, bg="#FFBB00", bd=5)
    headingFrame1.pack(pady=20)

    headingLabel = Label(headingFrame1, text="View Books", bg='black', fg='white', font=('Courier', 15))
    headingLabel.pack(fill=BOTH)

    # === Book list heading ===
    labelFrame = Frame(second_frame, bg='black')
    labelFrame.pack(pady=10, padx=10, fill=X)

    Label(labelFrame, text="%-10s%-40s%-30s%-20s" % ('ID', 'Title', 'Author', 'Status'),
          bg='black', fg='white', anchor='w', font=("Courier", 10)).pack(fill=X)
    Label(labelFrame, text="-" * 100, bg='black', fg='white').pack(fill=X)

    # === Fetch & Display books ===
    getBooks = "SELECT * FROM books"
    cur.execute(getBooks)
    data = cur.fetchall()

    for i in data:
        text = "%-20s%-30s%-30s%-10s" % (i[0], i[1], i[2], "Available" if i[3] else "Issued")
        Label(labelFrame, text=text, bg='black', fg='white', anchor='w', font=("Courier", 10)).pack(fill=X)

    # === Quit button ===
    quitBtn = Button(second_frame, text="Quit", bg='#f7f1e3', fg='black', command=root.destroy)
    quitBtn.pack(pady=20)

    tem.close()
    root.mainloop()

if __name__ == "__main__":
    View()
