from tkinter import *
from PIL import ImageTk,Image
import pymysql
from tkinter import messagebox
from admin_panel import *
from Student_panel import *
from Login import *
from View_books import *
from Add_book import *
from Issue_book import *
from Return_book import *


# Function to resize image according to window size
def resize_bg(event):
    global resized_img
    new_width = event.width
    new_height = event.height
    
    # Resize the image
    resized_image = original_bg_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
    resized_img = ImageTk.PhotoImage(resized_image)
    
    # Update canvas
    Canvas1.delete("all")  # Clear previous image
    Canvas1.create_image(0, 0, anchor=NW, image=resized_img)
    Canvas1.config(width=new_width, height=new_height)

def delete():
    print("delete")


def Home_page():
    headingFrame1 = Frame(root,bg="#ffff00",bd=5)
    headingFrame1.place(relx=0.2,rely=0.1,relwidth=0.6,relheight=0.16)

    headingLabel = Label(headingFrame1, text="Welcome to \n DataFlair Library", bg='#00ff99', fg='#ff0000', font=('Courier',18))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)

    login = Button(root,text="Login",bg='black', fg='white', command=log)
    login.place(relx=0.87,rely=0.01, relwidth=0.12,relheight=0.06)

    # background_color="#0000e3"
    background_color="black"
    Text_color="white"
    Font=('Courier',12)

    btn1 = Button(root,text="Issue Book",bg=background_color, fg=Text_color, font=Font, command=issue_book)
    btn1.place(relx=0.28,rely=0.4, relwidth=0.45,relheight=0.1)
        
    btn2 = Button(root,text="Return Book",bg=background_color, fg=Text_color, command=return_book, font=Font)
    btn2.place(relx=0.28,rely=0.5, relwidth=0.45,relheight=0.1)
        
    btn3 = Button(root,text="View Book List",bg=background_color, fg=Text_color, command=View, font=Font)
    btn3.place(relx=0.28,rely=0.6, relwidth=0.45,relheight=0.1)
    

if __name__=="__main__":
    # Load the original image globally
    original_bg_image = Image.open("lib.jpg")

    # Create root window
    root = Tk()
    root.title("Library")
    root.minsize(width=400, height=400)
    root.geometry("600x500")

    # Create Canvas
    Canvas1 = Canvas(root)
    Canvas1.pack(expand=True, fill=BOTH)

    # Global reference to keep image object alive
    resized_img = None

    # Bind the resize function to the window
    root.bind("<Configure>", resize_bg)

    Home_page()

    # Mainloop
    root.mainloop()